package template.tool;

import javax.swing.*;
import java.awt.*;
import java.util.*;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;

import processing.app.Base;

public class ShapeBuilder {
	String shapeType = "";
	Point firstPoint;
	Point secondPoint;
	String processingShape = "";
	Shape javaShape;
	String[] shapes = {"rect", "ellipse", "arc", "line", "point", "triangle", "quad"};
	String[] processingConstructors = {"rect(", "ellipse(", "arc(", "line(", "point(", "triangle(", "quad("};
	
	Color fill = new Color(255,255,255);
	Color stroke = new Color(0,0,0);
	int strokeSize = 1;
	int rotation = 0;
	
	ShapeBuilder(String initShapeType, Point initFirstPoint, Point initSecondPoint){
		shapeType = determineShapeType(initShapeType);
		firstPoint = initFirstPoint;
		secondPoint = initSecondPoint;
		if(firstPoint != null & secondPoint != null) {
			createShape();
		} else if (Arrays.asList(processingConstructors).contains(shapeType)){
			createShapeFromCode(initShapeType);
		}
	}
	
	public String determineShapeType(String currentType) {
		for (String shape: shapes) {
			if (currentType.toLowerCase().contains(shape+"(")) {
				processingShape = currentType;
				return shape+"(";
			} else if (currentType.toLowerCase().contains(shape)) {
				return shape;
			}
		}
		return "";
	}
	
	public String getProcessingFill() {
		return "fill(" + fill.getRed() + ", " + fill.getGreen() + ", " + fill.getBlue() + ");";
	}
	
	public String getProcessingStroke() {
		return "stroke(" + stroke.getRed() + ", " + stroke.getGreen() + ", " + stroke.getBlue() + ");";
	}
	
	public String getProcessingStrokeSize() {
		return "strokeWeight(" + strokeSize + ");";
	}
	
	public String getProcessingRotate() {
		return  "rotate(" + Math.toRadians(rotation) + ");";
	}
	
	public String getReverseProcessingRotate() {
		return  "rotate(-" + Math.toRadians(rotation) + ");";
	}
	
	public void createShapeFromCode(String s) {
		String[] values = s.replace(" ", "").split("\\(", 2)[1].split("\\)",2)[0].split(",");
		switch (shapeType) {
	        case "ellipse(":
				firstPoint = new Point(Integer.valueOf(values[0]),Integer.valueOf(values[1]));
				secondPoint = new Point(Integer.valueOf(values[0])+Integer.valueOf(values[2]),Integer.valueOf(values[1])+Integer.valueOf(values[3]));
				javaShape = new Ellipse2D.Double(Integer.valueOf(values[0]),Integer.valueOf(values[1]),Integer.valueOf(values[2]),Integer.valueOf(values[3]));
				break;
	        case "rect(":
				firstPoint = new Point(Integer.valueOf(values[0]),Integer.valueOf(values[1]));
				secondPoint = new Point(Integer.valueOf(values[0])+Integer.valueOf(values[2]),Integer.valueOf(values[1])+Integer.valueOf(values[3]));
				javaShape = new Rectangle(Integer.valueOf(values[0]),Integer.valueOf(values[1]),Integer.valueOf(values[2]),Integer.valueOf(values[3]));
				break;
	        case "triangle(":
				firstPoint = new Point(Integer.valueOf(values[0]),Integer.valueOf(values[1]));
				secondPoint = new Point(Integer.valueOf(values[4]),Integer.valueOf(values[5]));
				int[] x = {Integer.valueOf(values[0]),Integer.valueOf(values[2]),Integer.valueOf(values[4])};
				int[] y = {Integer.valueOf(values[1]),Integer.valueOf(values[3]),Integer.valueOf(values[5])};
				javaShape = new Polygon(x,y,3);
				break;
	        case "arc(":
				int smallX = Integer.valueOf(values[0])-(Integer.valueOf(values[2])/2);
				int smallY = Integer.valueOf(values[1])-(Integer.valueOf(values[3])/2);
				firstPoint = new Point(smallX,smallY);
				secondPoint = new Point(Integer.valueOf(values[0])+Integer.valueOf(values[2]),Integer.valueOf(values[1])+Integer.valueOf(values[3]));
				javaShape = new Arc2D.Double(smallX,smallY,Integer.valueOf(values[2]),Integer.valueOf(values[3]),(int)Math.toDegrees(Float.parseFloat(values[4])-Math.PI), (int)Math.toDegrees(Float.parseFloat(values[5])-Math.PI),Arc2D.PIE);
				break;
	        case "quad(":
				firstPoint = new Point(Integer.valueOf(values[0]),Integer.valueOf(values[1]));
				secondPoint = new Point(Integer.valueOf(values[4]),Integer.valueOf(values[5]));
				int[] xPos = {Integer.valueOf(values[0]),Integer.valueOf(values[2]),Integer.valueOf(values[4]),Integer.valueOf(values[6])};
				int[] yPos = {Integer.valueOf(values[1]),Integer.valueOf(values[3]),Integer.valueOf(values[5]),Integer.valueOf(values[7])};
				javaShape = new Polygon(xPos,yPos,4);
				break;
	        case "line(":
				firstPoint = new Point(Integer.valueOf(values[0]),Integer.valueOf(values[1]));
				secondPoint = new Point(Integer.valueOf(values[2]),Integer.valueOf(values[3]));
				javaShape = new Line2D.Double(Integer.valueOf(values[0]),Integer.valueOf(values[1]),Integer.valueOf(values[2]),Integer.valueOf(values[3]));
				break;
	        case "point(":
				firstPoint = new Point(Integer.valueOf(values[0]),Integer.valueOf(values[1]));
				secondPoint = new Point(Integer.valueOf(values[0]),Integer.valueOf(values[1]));
				javaShape = new Ellipse2D.Double(Integer.valueOf(values[0]),Integer.valueOf(values[1]),1,1);
				break;
		}
	}
	
	public void createShape() {
		int x1 = firstPoint.x;
    	int x2 = secondPoint.x;
    	int y1 = firstPoint.y;
    	int y2 = secondPoint.y;

    	int smallX = ((x1>x2) ? x2 : x1);
    	int smallY = ((y1>y2) ? y2 : y1);
    	
    	int bigX = ((x2>x1) ? x2 : x1);
    	int bigY = ((y2>y1) ? y2 : y1);
    	
		switch (shapeType) {
	        case "rect":
	        	processingShape = shapeType + "(" + x1 + ", " + y1 + ", " + Math.abs(x1-x2) + ", " + Math.abs(y1-y2) + ");";
	        	javaShape = new Rectangle(x1,y1, Math.abs(x1-x2),Math.abs(y1-y2));
	            break;
	 
	        case "ellipse":
	        	processingShape = shapeType + "(" + (int)((x1+x2)/2) + ", " + (int)((y1+y2)/2) + ", " + Math.abs(x1-x2) + ", " + Math.abs(y1-y2) + ");";
	        	javaShape = new Ellipse2D.Double(smallX,smallY, Math.abs(x1-x2),Math.abs(y1-y2));
	            break;
	 
	        case "triangle":
	        	processingShape = shapeType + "(" + x1 + ", " + y1 + ", " + Math.abs((2*x1)-x2) + ", " + y2 + ", " + x2 + ", " + y2 + ");";
	        	int[] x = {x1,Math.abs((2*x1)-x2),x2};
	        	int[] y = {y1,y2,y2};
	        	javaShape = new Polygon(x,y,3);
	            break;
	 
	        case "arc":
	        	double startAngle = 0;
	        	double endAngle = Math.PI;
	        	processingShape = shapeType + "(" + (int)((x1+x2)/2) + ", " + (int)((y1+y2)/2) + ", " + Math.abs(x1-x2) + ", " + Math.abs(y1-y2) + ", " + (startAngle+Math.PI) + ", " + (endAngle+Math.PI) + ", PIE);";
	        	javaShape = new Arc2D.Double(smallX,smallY, Math.abs(x1-x2), Math.abs(y1-y2), (int)Math.toDegrees(startAngle), (int)Math.toDegrees(endAngle), Arc2D.PIE);
	        	break;
	 
	        case "quad":
	        	int[] xPos = {smallX,smallX+(int)(Math.abs(x1-x2)*0.75),bigX,smallX+(int)(Math.abs(x1-x2)*0.25)};
	        	int[] yPos =  {smallY,smallY,bigY,bigY};
	        	processingShape = shapeType + "(" + xPos[0] + ", " + yPos[0] + ", " + xPos[1] + ", " + yPos[1] + ", " + xPos[2] + ", " + yPos[2] + ", " + xPos[3] + ", " + yPos[3] + ");";
	        	javaShape = new Polygon(xPos,yPos,4);
	            break;
	 
	        case "line":
	        	processingShape = shapeType + "(" + x1 + ", " + y1 + ", " + x2 + ", " + y2 + ");";
	        	javaShape = new Line2D.Double(x1, y1, x2, y2);
	            break;
	 
	        case  "point":
	        	processingShape = shapeType + "(" + x1 + ", " + y1 + ");";
	        	javaShape = new Ellipse2D.Double(x1,y1,1,1);
	            break;
		}
	}
	
	public void moveShape(Point newPoint) {
		int x1 = newPoint.x - Math.abs(firstPoint.x-secondPoint.x)/2;
		int y1 = newPoint.y - Math.abs(firstPoint.y-secondPoint.y)/2;
		int x2 = newPoint.x + Math.abs(firstPoint.x-secondPoint.x)/2;
		int y2 = newPoint.y + Math.abs(firstPoint.y-secondPoint.y)/2;
		firstPoint = new Point(x1,y1);
		secondPoint = new Point(x2,y2);
		createShape();
	}
	
	public void stretchShape(Point newPoint, int cursor) {
		switch (cursor) {
			case Cursor.NW_RESIZE_CURSOR:
				firstPoint = newPoint;
				break;
			case Cursor.SW_RESIZE_CURSOR:
				firstPoint = new Point(newPoint.x,firstPoint.y);
				secondPoint = new Point(secondPoint.x,newPoint.y);
				break;
			case Cursor.W_RESIZE_CURSOR:
				firstPoint = new Point(newPoint.x,firstPoint.y);
				break;
			case Cursor.NE_RESIZE_CURSOR:
				firstPoint = new Point(firstPoint.x,newPoint.y);
				secondPoint = new Point(newPoint.x,secondPoint.y);
				break;
			case Cursor.SE_RESIZE_CURSOR:
				secondPoint = newPoint;
				break;
			case Cursor.E_RESIZE_CURSOR:
				secondPoint = new Point(newPoint.x,secondPoint.y);
				break;
			case Cursor.N_RESIZE_CURSOR:
				firstPoint = new Point(firstPoint.x,newPoint.y);
				break;
			case Cursor.S_RESIZE_CURSOR:
				secondPoint = new Point(secondPoint.x,newPoint.y);
				break;
		}
		createShape();
	}
}
